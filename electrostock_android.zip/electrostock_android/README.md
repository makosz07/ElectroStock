# ⚡ ElectroStock — Android App

Aplikacja Android do zarządzania magazynem podzespołów elektronicznych.

## Jak zbudować APK przez GitHub

1. Wgraj ten folder na GitHub (nowe repozytorium)
2. GitHub automatycznie uruchomi budowanie (Actions)
3. Po ~3-5 minutach wejdź w **Actions → Build APK → Artifacts**
4. Pobierz `ElectroStock-debug.apk`

## Zmiana adresu serwera

Otwórz plik:
```
app/src/main/java/pl/thumbrex/electrostock/MainActivity.java
```

Zmień linię:
```java
private static final String SERVER_URL = "http://85.215.139.236";
```

Na swój adres lub domenę.

## Struktura projektu

```
electrostock_android/
├── .github/workflows/
│   └── build.yml          ← automatyczne budowanie APK
├── app/
│   ├── src/main/
│   │   ├── java/.../
│   │   │   ├── MainActivity.java    ← główna aktywność (WebView)
│   │   │   └── SplashActivity.java  ← ekran powitalny
│   │   ├── res/
│   │   │   ├── layout/   ← układy XML
│   │   │   ├── values/   ← kolory, stringi, motywy
│   │   │   └── mipmap-*/  ← ikony
│   │   └── AndroidManifest.xml
│   └── build.gradle
└── build.gradle
```
