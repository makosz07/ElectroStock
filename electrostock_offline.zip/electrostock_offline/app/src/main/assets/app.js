/**
 * ElectroStock — App Logic (offline SPA)
 * Działa w 100% lokalnie. Brak połączeń sieciowych.
 */

'use strict';

// ═══════════════════════════════════════════
//  STATE
// ═══════════════════════════════════════════
const S = {
  user:        null,
  view:        'all',
  filterCat:   null,
  filterPlat:  null,
  searchQuery: '',
  lang:        'pl',
  theme:       'dark',
  authMode:    'login',  // 'login' | 'register'
};

// ═══════════════════════════════════════════
//  I18N
// ═══════════════════════════════════════════
const LANGS = {
  pl: {
    login:'Zaloguj się', register:'Zarejestruj się', username:'Użytkownik', password:'Hasło', appSub:'Magazyn komponentów elektronicznych', backup:'Kopia zapasowa', dangerZone:'Usuwanie danych',
    noAccount:'Nie masz konta?', hasAccount:'Masz już konto?', registerLink:'Zarejestruj się',
    loginLink:'Zaloguj się', allParts:'Wszystkie części', lowStock:'Niski stan',
    search:'Szukaj', settings:'Ustawienia', categories:'Kategorie', platforms:'Platformy',
    addPart:'Dodaj komponent', editPart:'Edytuj komponent', deletePart:'Usuń',
    name:'Nazwa', symbol:'Symbol/Nr katal.', category:'Kategoria', description:'Opis',
    quantity:'Stan', minQty:'Min. stan', maxQty:'Maks. stan', unit:'Jednostka',
    location:'Lokalizacja', datasheet:'Datasheet URL', price:'Cena jedn.', notes:'Notatki',
    save:'Zapisz', cancel:'Anuluj', confirm:'Potwierdź', yes:'Tak', no:'Nie',
    delete:'Usuń', edit:'Edytuj', add:'Dodaj', close:'Zamknij',
    addCategory:'Dodaj kategorię', editCategory:'Edytuj kategorię',
    addPlatform:'Dodaj platformę', editPlatform:'Edytuj platforma',
    total:'Wszystkich', lowStockLbl:'Niski stan', totalQty:'Łącznie szt.',
    noResults:'Brak wyników', noPartsYet:'Brak komponentów',
    addFirst:'Dodaj swój pierwszy komponent klikając + w prawym górnym rogu.',
    adjust:'Koryguj stan', stockIn:'Przyjęcie', stockOut:'Wydanie',
    setStock:'Ustaw ilość', history:'Historia', logEmpty:'Brak historii',
    logout:'Wyloguj', manage:'Zarządzaj', all:'Wszystkie',
    exportOk:'Eksport gotowy', importOk:'Import zakończony', importErr:'Błąd importu',
    catManager:'Zarządzaj kategoriami', platManager:'Zarządzaj platformami',
    language:'Język', themeLabel:'Motyw', dark:'Ciemny', light:'Jasny',
    deleteConfirm:'Czy na pewno usunąć', cannotUndo:'Tej operacji nie można cofnąć.',
    saved:'Zapisano', deleted:'Usunięto', error:'Błąd',
    email:'E-mail (opcjonalnie)', icon:'Ikona', color:'Kolor',
    compatPlatforms:'Kompatybilne platformy', tags:'Tagi (oddzielone przecinkiem)',
    partHistory:'Historia komponentu', allHistory:'Historia magazynu',
    inventory:'Inwentarz', data:'Dane', userSettings:'Ustawienia konta',
    wrongPass:'Nieprawidłowe hasło', userExists:'Użytkownik już istnieje', notFound:'Nie znaleziono',
    fillFields:'Uzupełnij wymagane pola', minLen:'Minimum 4 znaki', noSearch:'Wpisz frazę do wyszukania',
    value:'Wartość magazynu', export:'Eksportuj', import:'Importuj', accountAbout:'O aplikacji', storage:'Przechowywanie', localData:'Pliki są przechowywane tylko lokalnie',
    deleteAllData:'Usuń wszystkie dane', deleteStock:'Usuń stany magazynowe', deleteStockSub:'Usuwa wszystkie komponenty z magazynu. Kategorie i platformy zostają.',
    deleteAllSub:'Usuwa komponenty, kategorie, platformy i historię.', exportJson:'Eksportuj JSON', importJson:'Importuj JSON', localOnlyNote:'Dane i pliki kopii zapasowej są przechowywane tylko lokalnie na tym urządzeniu.', version:'Wersja',
  },
  en: {
    login:'Log in', register:'Register', username:'Username', password:'Password', appSub:'Electronic components inventory', backup:'Backup', dangerZone:'Data deletion',
    noAccount:"Don't have an account?", hasAccount:'Have an account?', registerLink:'Register',
    loginLink:'Log in', allParts:'All parts', lowStock:'Low stock',
    search:'Search', settings:'Settings', categories:'Categories', platforms:'Platforms',
    addPart:'Add component', editPart:'Edit component', deletePart:'Delete',
    name:'Name', symbol:'Symbol/Part no.', category:'Category', description:'Description',
    quantity:'Quantity', minQty:'Min. qty', maxQty:'Max. qty', unit:'Unit',
    location:'Location', datasheet:'Datasheet URL', price:'Unit price', notes:'Notes',
    save:'Save', cancel:'Cancel', confirm:'Confirm', yes:'Yes', no:'No',
    delete:'Delete', edit:'Edit', add:'Add', close:'Close',
    addCategory:'Add category', editCategory:'Edit category',
    addPlatform:'Add platform', editPlatform:'Edit platform',
    total:'Total', lowStockLbl:'Low stock', totalQty:'Total units',
    noResults:'No results', noPartsYet:'No components yet',
    addFirst:'Add your first component by tapping + in the top right.',
    adjust:'Adjust stock', stockIn:'Stock in', stockOut:'Stock out',
    setStock:'Set quantity', history:'History', logEmpty:'No history',
    logout:'Log out', manage:'Manage', all:'All',
    exportOk:'Export ready', importOk:'Import complete', importErr:'Import error',
    catManager:'Manage categories', platManager:'Manage platforms',
    language:'Language', themeLabel:'Theme', dark:'Dark', light:'Light',
    deleteConfirm:'Really delete', cannotUndo:'This action cannot be undone.',
    saved:'Saved', deleted:'Deleted', error:'Error',
    email:'E-mail (optional)', icon:'Icon', color:'Color',
    compatPlatforms:'Compatible platforms', tags:'Tags (comma separated)',
    partHistory:'Part history', allHistory:'Warehouse history',
    inventory:'Inventory', data:'Data', userSettings:'Account settings',
    wrongPass:'Wrong password', userExists:'User already exists', notFound:'Not found',
    fillFields:'Fill in required fields', minLen:'Minimum 4 characters', noSearch:'Enter a search phrase',
    value:'Stock value', export:'Export', import:'Import', accountAbout:'About app', storage:'Storage', localData:'Files are stored locally only',
    deleteAllData:'Delete all data', deleteStock:'Delete inventory only', deleteStockSub:'Deletes all inventory components. Categories and platforms stay.',
    deleteAllSub:'Deletes components, categories, platforms and history.', exportJson:'Export JSON', importJson:'Import JSON', localOnlyNote:'Data and backup files are stored locally on this device only.', version:'Version',
  },
  es: {
    login:'Iniciar sesión', register:'Registrarse', username:'Usuario', password:'Contraseña', appSub:'Inventario de componentes electrónicos', backup:'Copia de seguridad', dangerZone:'Eliminación de datos',
    noAccount:'¿No tienes cuenta?', hasAccount:'¿Ya tienes cuenta?', registerLink:'Registrarse',
    loginLink:'Iniciar sesión', allParts:'Todas las piezas', lowStock:'Stock bajo',
    search:'Buscar', settings:'Ajustes', categories:'Categorías', platforms:'Plataformas',
    addPart:'Añadir componente', editPart:'Editar componente', deletePart:'Eliminar',
    name:'Nombre', symbol:'Símbolo/Nº de pieza', category:'Categoría', description:'Descripción',
    quantity:'Cantidad', minQty:'Cantidad mín.', maxQty:'Cantidad máx.', unit:'Unidad',
    location:'Ubicación', datasheet:'URL de datasheet', price:'Precio unit.', notes:'Notas',
    save:'Guardar', cancel:'Cancelar', confirm:'Confirmar', yes:'Sí', no:'No',
    delete:'Eliminar', edit:'Editar', add:'Añadir', close:'Cerrar',
    addCategory:'Añadir categoría', editCategory:'Editar categoría',
    addPlatform:'Añadir plataforma', editPlatform:'Editar plataforma',
    total:'Total', lowStockLbl:'Stock bajo', totalQty:'Unidades',
    noResults:'Sin resultados', noPartsYet:'Sin componentes',
    addFirst:'Añade tu primer componente tocando + arriba a la derecha.',
    adjust:'Ajustar stock', stockIn:'Entrada', stockOut:'Salida',
    setStock:'Establecer cantidad', history:'Historial', logEmpty:'Sin historial',
    logout:'Cerrar sesión', manage:'Gestionar', all:'Todas',
    export:'Exportar', import:'Importar', exportOk:'Exportación lista', importOk:'Importación completa', importErr:'Error de importación',
    catManager:'Gestionar categorías', platManager:'Gestionar plataformas',
    language:'Idioma', themeLabel:'Tema', dark:'Oscuro', light:'Claro',
    deleteConfirm:'¿Seguro que quieres eliminar', cannotUndo:'Esta operación no se puede deshacer.',
    saved:'Guardado', deleted:'Eliminado', error:'Error',
    icon:'Icono', color:'Color',
    compatPlatforms:'Plataformas compatibles', tags:'Etiquetas (separadas por comas)',
    partHistory:'Historial del componente', allHistory:'Historial del almacén',
    inventory:'Inventario', data:'Datos', userSettings:'Ajustes de cuenta',
    wrongPass:'Contraseña incorrecta', userExists:'El usuario ya existe', notFound:'No encontrado',
    fillFields:'Completa los campos requeridos', minLen:'Mínimo 4 caracteres', noSearch:'Introduce una frase de búsqueda',
    value:'Valor del stock', accountAbout:'Acerca de la aplicación', storage:'Almacenamiento', localData:'Los archivos se almacenan solo localmente',
    deleteAllData:'Eliminar todos los datos', deleteStock:'Borrar inventario', deleteStockSub:'Elimina todos los componentes del inventario. Las categorías y plataformas se quedan.',
    deleteAllSub:'Elimina componentes, categorías, plataformas e historial.', exportJson:'Exportar JSON', importJson:'Importar JSON', localOnlyNote:'Los datos y copias de seguridad se guardan solo localmente en este dispositivo.', version:'Versión',
  },
};
const t = key => (LANGS[S.lang]||LANGS.pl)[key] || key;

const DEFAULT_CATEGORY_NAMES = {
  'Rezystory': { en:'Resistors', es:'Resistencias' },
  'Kondensatory': { en:'Capacitors', es:'Condensadores' },
  'Tranzystory': { en:'Transistors', es:'Transistores' },
  'Diody': { en:'Diodes', es:'Diodos' },
  'Układy scalone': { en:'Integrated circuits', es:'Circuitos integrados' },
  'Złącza': { en:'Connectors', es:'Conectores' },
  'Cewki i dławiki': { en:'Coils and chokes', es:'Bobinas y choques' },
  'Indukcyjności': { en:'Coils and chokes', es:'Bobinas y choques' },
  'Mikrokontrolery': { en:'Microcontrollers', es:'Microcontroladores' },
  'Zasilanie': { en:'Power', es:'Alimentación' },
  'Inne': { en:'Other', es:'Otros' },
};
const DEFAULT_PART_NAMES = {
  'Rezystor 10kΩ 1/4W': { en:'10kΩ resistor 1/4W', es:'Resistencia 10kΩ 1/4W' },
  'Rezystor 1kΩ 1/4W': { en:'1kΩ resistor 1/4W', es:'Resistencia 1kΩ 1/4W' },
  'Kondensator 100nF ceramiczny': { en:'100nF ceramic capacitor', es:'Condensador cerámico 100nF' },
  'LED czerwona 5mm': { en:'Red LED 5mm', es:'LED rojo 5mm' },
  'ATmega328P': { en:'ATmega328P', es:'ATmega328P' },
};
function trCategoryName(name) { return (DEFAULT_CATEGORY_NAMES[name] && DEFAULT_CATEGORY_NAMES[name][S.lang]) || name || ''; }
function trPartName(name) { return (DEFAULT_PART_NAMES[name] && DEFAULT_PART_NAMES[name][S.lang]) || name || ''; }
function trUnit(unit) { if (unit === 'szt.') return S.lang === 'en' ? 'pcs' : (S.lang === 'es' ? 'uds.' : 'szt.'); return unit || ''; }

// ═══════════════════════════════════════════
//  INIT
// ═══════════════════════════════════════════
window.addEventListener('DOMContentLoaded', async () => {
  await openDB();

  const savedLang = localStorage.getItem('es_lang');
  if (['pl','en','es'].includes(savedLang)) S.lang = savedLang;

  // Restore session
  const saved = sessionStorage.getItem('es_user');
  if (saved) {
    const u = await getUser(saved);
    if (u) {
      S.user = u;
      const preferredLang = ['pl','en','es'].includes(savedLang) ? savedLang : (u.settings?.lang || 'pl');
      S.lang  = preferredLang;
      S.theme = u.settings?.theme || 'dark';
      if (u.settings?.lang !== preferredLang) {
        await updateUserSettings(u.username, { lang: preferredLang });
        S.user = await getUser(u.username);
      }
    }
  }

  applyTheme();
  const authLang = document.getElementById('authLang');
  if (authLang) authLang.value = S.lang;
  const splashSub = document.getElementById('splashSub');
  if (splashSub) splashSub.textContent = t('appSub');

  // Hide splash after animation
  setTimeout(() => {
    document.getElementById('splash').style.display = 'none';
    if (S.user) showApp();
    else        showLogin();
  }, 1900);
});

// ═══════════════════════════════════════════
//  THEME
// ═══════════════════════════════════════════
function applyTheme() {
  document.body.className = S.theme === 'light' ? 'light' : '';
}

// ═══════════════════════════════════════════
//  AUTH
// ═══════════════════════════════════════════
function showLogin() {
  document.getElementById('appView').classList.add('hidden');
  document.getElementById('loginView').classList.remove('hidden');
  setAuthMode(S.authMode);
}

function toggleAuthMode() {
  S.authMode = S.authMode === 'login' ? 'register' : 'login';
  setAuthMode(S.authMode);
}

async function setAuthLang(lang) {
  S.lang = ['pl','en','es'].includes(lang) ? lang : 'pl';
  localStorage.setItem('es_lang', S.lang);
  const authLang = document.getElementById('authLang');
  if (authLang) authLang.value = S.lang;
  if (S.user?.username) {
    await updateUserSettings(S.user.username, { lang: S.lang });
    S.user = await getUser(S.user.username);
  }
  setAuthMode(S.authMode);
}

function setAuthMode(mode) {
  S.authMode = mode;
  const isLogin = mode === 'login';
  document.getElementById('authBtn').textContent = isLogin ? t('login') : t('register');
  document.getElementById('loginSwitchTxt').textContent  = isLogin ? t('noAccount') : t('hasAccount');
  document.getElementById('loginSwitchLink').textContent = isLogin ? t('registerLink') : t('loginLink');
  const userLabel = document.querySelector('label[for="loginUser"]');
  const passLabel = document.querySelector('label[for="loginPass"]');
  if (userLabel) userLabel.textContent = t('username');
  if (passLabel) passLabel.textContent = t('password');
  const note = document.getElementById('localOnlyNote');
  if (note) note.textContent = t('localOnlyNote');
  const sub = document.getElementById('loginSub');
  if (sub) sub.textContent = t('appSub');
  const authLang = document.getElementById('authLang');
  if (authLang) authLang.value = S.lang;
  const userInput = document.getElementById('loginUser');
  const passInput = document.getElementById('loginPass');
  if (userInput) userInput.placeholder = t('username').toLowerCase();
  if (passInput) passInput.placeholder = '••••••';
  hideError();
}

async function doAuth() {
  const username = document.getElementById('loginUser').value.trim();
  const password = document.getElementById('loginPass').value;
  const selectedLang = ['pl','en','es'].includes(S.lang) ? S.lang : 'pl';
  hideError();

  if (!username || !password) { showError(t('fillFields')); return; }
  if (username.length < 3)    { showError(t('minLen'));     return; }

  if (S.authMode === 'login') {
    const u = await getUser(username);
    if (!u) { showError(t('notFound')); return; }
    if (u.passwordHash !== hashPassword(password)) { showError(t('wrongPass')); return; }
    await updateUserSettings(username, { lang: selectedLang });
    S.user = await getUser(username);
  } else {
    const existing = await getUser(username);
    if (existing) { showError(t('userExists')); return; }
    await createUser(username, hashPassword(password));
    await updateUserSettings(username, { lang: selectedLang, theme: S.theme });
    await seedDefaults(username);
    S.user = await getUser(username);
  }

  S.lang = selectedLang;
  localStorage.setItem('es_lang', S.lang);
  S.theme = S.user.settings?.theme || 'dark';
  applyTheme();
  sessionStorage.setItem('es_user', username);
  showApp();
}

function doLogout() {
  sessionStorage.removeItem('es_user');
  S.user = null; S.filterCat = null; S.filterPlat = null; S.searchQuery = '';
  closeSidebar();
  document.getElementById('appView').classList.add('hidden');
  showLogin();
}

function showError(msg) {
  const el = document.getElementById('loginError');
  el.textContent = msg; el.classList.remove('hidden');
}
function hideError() { document.getElementById('loginError').classList.add('hidden'); }

// ═══════════════════════════════════════════
//  APP
// ═══════════════════════════════════════════
async function showApp() {
  document.getElementById('loginView').classList.add('hidden');
  document.getElementById('appView').classList.remove('hidden');
  document.getElementById('sidebarUsername').textContent = S.user.username;
  await applyCatalogPatch();
  await renderSidebar();
  navigate('all');
}

async function applyCatalogPatch() {
  if (!S.user || S.user.settings?.catalogPatch20260518 === true) return;

  const desiredCats = [
    ['Rezystory','🟫'], ['Kondensatory','🟦'], ['Tranzystory','🔺'], ['Diody','💡'],
    ['Układy scalone','🧩'], ['Złącza','🔌'], ['Cewki i dławiki','🌀'],
    ['Mikrokontrolery','💻'], ['Zasilanie','🔋'], ['Inne','📦']
  ];

  const cats = await getCategories(S.user.username);
  const byName = Object.fromEntries(cats.map(c => [c.name, c]));
  for (const c of cats) {
    if (c.name === 'Indukcyjności') await updateCategory(c.id, 'Cewki i dławiki', '🌀');
  }
  const refreshed = await getCategories(S.user.username);
  const refreshedByName = Object.fromEntries(refreshed.map(c => [c.name, c]));
  for (const [name, icon] of desiredCats) {
    if (refreshedByName[name]) await updateCategory(refreshedByName[name].id, name, icon);
    else await addCategory(S.user.username, name, icon);
  }

  const parts = await getParts(S.user.username);
  for (const p of parts) await deletePart(p.id);
  if (typeof deleteLogForUser === 'function') await deleteLogForUser(S.user.username);

  await addPart(S.user.username, { name: 'LED czerwona 5mm', symbol: 'LEDR5', category: 'Diody', icon: '💡', quantity: 2, minQty: 5, unit: 'szt.', location: 'C1-1', platforms: [] });
  await addPart(S.user.username, { name: 'Rezystor 10kΩ 1/4W', symbol: 'R10K', category: 'Rezystory', icon: '🟫', quantity: 100, minQty: 20, unit: 'szt.', location: 'A1-1', platforms: [] });

  await updateUserSettings(S.user.username, { catalogPatch20260518: true, lang: S.lang });
  S.user = await getUser(S.user.username);
}

// ═══════════════════════════════════════════
//  SIDEBAR
// ═══════════════════════════════════════════
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('sidebarOverlay');
  const open = sb.classList.contains('open');
  sb.classList.toggle('open', !open);
  ov.classList.toggle('hidden', open);
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.add('hidden');
}

async function renderSidebar() {
  document.getElementById('sidebarRole').textContent = S.lang === 'en' ? 'user' : (S.lang === 'es' ? 'usuario' : 'użytkownik');
  document.querySelectorAll('.sidebar-section-title')[0].textContent = String(t('inventory')).toUpperCase();
  document.querySelector('#navAll span:last-child').textContent = t('allParts');
  document.querySelector('#navLow span:last-child').textContent = t('lowStock');
  document.querySelectorAll('.sidebar-section-title')[1].textContent = String(t('categories')).toUpperCase();
  document.querySelectorAll('.sidebar-section-title')[2].textContent = String(t('platforms')).toUpperCase();
  document.querySelectorAll('.sidebar-section-title')[3].textContent = String(t('data')).toUpperCase();
  await renderCategoryList();
  await renderPlatformList();
  const manageLinks = document.querySelectorAll('.sidebar-link-muted span:last-child');
  if (manageLinks[0]) manageLinks[0].textContent = t('catManager');
  if (manageLinks[1]) manageLinks[1].textContent = t('platManager');
  const navAllPlat = document.querySelector('#navAllPlat span:last-child');
  if (navAllPlat) navAllPlat.textContent = S.lang === 'pl' ? 'Wszystkie platformy' : (S.lang === 'en' ? 'All platforms' : 'Todas las plataformas');
  const sections = document.querySelectorAll('.sidebar-section');
  const dataSection = sections[3];
  const dataLinks = dataSection ? dataSection.querySelectorAll('.sidebar-link span:last-child') : [];
  if (dataLinks[0]) dataLinks[0].textContent = t('settings');
}

async function renderCategoryList() {
  const cats = await getCategories(S.user.username);
  const el = document.getElementById('categoryList');
  el.innerHTML = '';
  // "All" link
  const allLink = makeEl('a', 'sidebar-link' + (S.filterCat === null && S.filterPlat === null && S.view === 'all' ? ' active' : ''));
  allLink.innerHTML = `<span class="sidebar-icon">📋</span><span>${t('allParts')}</span>`;
  allLink.onclick = () => navigate('all');
  el.appendChild(allLink);

  cats.sort((a,b)=>a.name.localeCompare(b.name));
  for (const c of cats) {
    const a = makeEl('a', 'sidebar-link' + (S.filterCat === c.id ? ' active' : ''));
    a.innerHTML = `<span class="sidebar-icon">${esc(c.icon)}</span><span class="ellipsis">${esc(trCategoryName(c.name))}</span>`;
    a.onclick = () => filterByCategory(c.id);
    el.appendChild(a);
  }
}

async function renderPlatformList() {
  const plats = await getPlatforms(S.user.username);
  const el = document.getElementById('platformList');
  el.innerHTML = '';
  plats.sort((a,b)=>a.name.localeCompare(b.name));
  for (const p of plats) {
    const a = makeEl('a', 'sidebar-link' + (S.filterPlat === p.id ? ' active' : ''));
    a.innerHTML = `<span class="sidebar-icon" style="color:${p.color}">▣</span><span class="ellipsis">${esc(p.name)}</span>`;
    a.onclick = () => filterByPlatform(p.id);
    el.appendChild(a);
  }
}

function filterByCategory(id) {
  S.filterCat = id; S.filterPlat = null; S.view = 'all';
  closeSidebar();
  renderSidebar();
  renderPartsList();
}
function filterByPlatform(id) {
  S.filterPlat = id; S.filterCat = null; S.view = 'all';
  closeSidebar();
  renderSidebar();
  renderPartsList();
}

// ═══════════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════════
function navigate(view) {
  S.view = view;
  if (view === 'all') {
    S.filterCat = null; S.filterPlat = null; S.searchQuery = '';
  } else if (view !== 'low') {
    S.filterCat = null; S.filterPlat = null;
  }
  closeSidebar();
  const titles = { all: 'ElectroStock', low: t('lowStock'), search: t('search'), settings: t('settings') };
  document.getElementById('topbarTitle').textContent = titles[view] || 'ElectroStock';
  renderSidebar();

  const mc = document.getElementById('mainContent');
  if (view === 'settings') { renderSettings(mc); return; }
  if (view === 'search')   { renderSearch(mc);   return; }
  renderPartsList(mc);
}

// ═══════════════════════════════════════════
//  PARTS LIST
// ═══════════════════════════════════════════
async function renderPartsList(container) {
  const mc = container || document.getElementById('mainContent');
  mc.innerHTML = '<div class="empty-state"><div class="empty-icon">⏳</div></div>';

  const filters = {};
  if (S.filterCat)   filters.category = await getCategoryName(S.filterCat);
  if (S.filterPlat)  filters.platform = await getPlatformName(S.filterPlat);
  if (S.view === 'low') filters.lowStock = true;
  if (S.searchQuery) filters.q = S.searchQuery;

  const parts = await getParts(S.user.username, filters);
  const stats = getStatsFromParts(parts);

  mc.innerHTML = '';

  // Stats bar
  const sb = makeEl('div', 'stats-bar');
  sb.innerHTML = `
    <div class="stat-card"><div class="stat-val">${stats.total}</div><div class="stat-lbl">${t('total')}</div></div>
    <div class="stat-card"><div class="stat-val" style="color:var(--danger)">${stats.lowStock}</div><div class="stat-lbl">${t('lowStockLbl')}</div></div>
    <div class="stat-card"><div class="stat-val">${stats.totalQty}</div><div class="stat-lbl">${t('totalQty')}</div></div>
  `;
  mc.appendChild(sb);

  // Active filters display
  if (S.filterCat || S.filterPlat) {
    const af = makeEl('div', 'active-filters');
    if (S.filterCat) {
      const name = await getCategoryName(S.filterCat);
      af.innerHTML += `<span class="filter-chip">📦 ${esc(trCategoryName(name))} <button onclick="filterByCategory(null)">✕</button></span>`;
    }
    if (S.filterPlat) {
      const name = await getPlatformName(S.filterPlat);
      af.innerHTML += `<span class="filter-chip">▣ ${esc(name)} <button onclick="filterByPlatform(null)">✕</button></span>`;
    }
    mc.appendChild(af);
  }

  // Parts grid
  if (parts.length === 0) {
    const es = makeEl('div', 'empty-state');
    es.innerHTML = `<div class="empty-icon">${S.view==='low'?'✅':'📦'}</div>
      <div class="empty-title">${S.filterCat||S.filterPlat||S.searchQuery ? t('noResults') : t('noPartsYet')}</div>
      <div class="empty-sub">${!S.filterCat&&!S.filterPlat&&!S.searchQuery ? t('addFirst') : ''}</div>`;
    mc.appendChild(es);
    return;
  }

  const cats = Object.fromEntries((await getCategories(S.user.username)).map(c=>[c.name,c]));
  const plats = Object.fromEntries((await getPlatforms(S.user.username)).map(p=>[p.id,p]));

  const grid = makeEl('div', 'parts-grid');
  for (const p of parts) {
    const stockClass = (p.minQty>0 && p.quantity<=0) ? 'low'
                     : (p.minQty>0 && p.quantity<=p.minQty) ? 'warn' : '';
    const catIcon = cats[p.category]?.icon || '📦';
    const platTags = (p.platforms||[]).map(pid => {
      const pl = plats[pid];
      return pl ? `<span class="tag platform" style="border-color:${pl.color}40;color:${pl.color}">${esc(pl.name)}</span>` : '';
    }).join('');

    const card = makeEl('div', 'part-card');
    card.innerHTML = `
      <div class="part-card-top">
        <div class="part-card-icon">${esc(p.icon||catIcon)}</div>
        <div class="part-card-info">
          <div class="part-card-name">${esc(trPartName(p.name))}</div>
          <div class="part-card-meta">${esc(p.symbol||'')}${p.symbol&&p.category?' · ':''}${esc(trCategoryName(p.category||''))}${p.location?' · 📍'+esc(p.location):''}</div>
        </div>
        <div class="part-card-right">
          <div class="part-card-stock ${stockClass}">${p.quantity}</div>
          <div class="part-card-unit">${esc(trUnit(p.unit||'szt.'))}</div>
        </div>
      </div>
      ${platTags ? `<div class="part-card-tags">${platTags}</div>` : ''}
    `;
    card.onclick = () => openPartDetail(p.id);
    grid.appendChild(card);
  }
  mc.appendChild(grid);
}

async function getCategoryName(id) {
  if (!id) return '';
  const cats = await getCategories(S.user.username);
  return cats.find(c=>c.id===id)?.name || '';
}
async function getPlatformName(id) {
  if (!id) return '';
  const plats = await getPlatforms(S.user.username);
  return plats.find(p=>p.id===id)?.name || '';
}

function getStatsFromParts(parts) {
  const list = Array.isArray(parts) ? parts : [];
  return {
    total: list.length,
    lowStock: list.filter(p => (Number(p.minQty)||0) > 0 && Number(p.quantity) <= Number(p.minQty)).length,
    totalQty: list.reduce((sum, p) => sum + (Number(p.quantity)||0), 0),
  };
}

// ═══════════════════════════════════════════
//  PART DETAIL MODAL
// ═══════════════════════════════════════════
async function openPartDetail(id) {
  const [part, cats, plats] = await Promise.all([
    getPartById(id),
    getCategories(S.user.username),
    getPlatforms(S.user.username),
  ]);
  if (!part) return;

  const stockClass = (part.minQty>0 && part.quantity<=0) ? ' low' : '';
  const platMap = Object.fromEntries(plats.map(p=>[p.id,p]));
  const platTags = (part.platforms||[]).map(pid=>platMap[pid]?.name||'').filter(Boolean).join(', ');

  const body = `
    <div class="detail-section">
      <div style="text-align:center; margin-bottom: 16px;">
        <div style="font-size:48px;">${esc(part.icon||'🔩')}</div>
        <div class="detail-stock${stockClass}">${part.quantity} <span style="font-size:14px;font-weight:400;color:var(--sub)">${esc(trUnit(part.unit||'szt.'))}</span></div>
      </div>
      <div class="stock-controls">
        <button class="stock-btn" onclick="quickAdjust(${id}, -10)">−10</button>
        <button class="stock-btn" onclick="quickAdjust(${id}, -1)">−1</button>
        <input class="input stock-input" type="number" id="qtyInput" value="${part.quantity}" min="0">
        <button class="stock-btn" onclick="quickAdjust(${id}, 1)">+1</button>
        <button class="stock-btn" onclick="quickAdjust(${id}, 10)">+10</button>
      </div>
      <button class="btn btn-secondary w100 mt8" onclick="applyQtyInput(${id})">${t('setStock')}</button>
    </div>

    <div class="section-divider">${t('name')}</div>
    <div class="detail-row"><div class="detail-value bold">${esc(trPartName(part.name))}</div></div>
    ${part.symbol ? `<div class="detail-row"><div class="detail-label">${t('symbol')}</div><div class="detail-value">${esc(part.symbol)}</div></div>` : ''}
    ${part.category ? `<div class="detail-row"><div class="detail-label">${t('category')}</div><div class="detail-value">${esc(trCategoryName(part.category))}</div></div>` : ''}
    ${part.location ? `<div class="detail-row"><div class="detail-label">📍 ${t('location')}</div><div class="detail-value">${esc(part.location)}</div></div>` : ''}
    ${part.description ? `<div class="detail-row"><div class="detail-label">${t('description')}</div><div class="detail-value">${esc(part.description)}</div></div>` : ''}
    ${platTags ? `<div class="detail-row"><div class="detail-label">${t('platforms')}</div><div class="detail-value">${esc(platTags)}</div></div>` : ''}
    ${part.minQty>0 ? `<div class="detail-row"><div class="detail-label">Min</div><div class="detail-value">${part.minQty} ${esc(trUnit(part.unit||'szt.'))}</div></div>` : ''}
    ${part.price>0  ? `<div class="detail-row"><div class="detail-label">${t('price')}</div><div class="detail-value">${part.price} ${esc(part.currency||'PLN')}</div></div>` : ''}
    ${part.notes    ? `<div class="detail-row"><div class="detail-label">${t('notes')}</div><div class="detail-value">${esc(part.notes)}</div></div>` : ''}
    ${part.datasheet? `<div class="detail-row"><div class="detail-label">Datasheet</div><div class="detail-value"><a href="${esc(part.datasheet)}" target="_blank" style="color:var(--info)">↗ otwórz</a></div></div>` : ''}
  `;

  const footer = `
    <button class="btn btn-secondary" onclick="openHistory(${id})">📋</button>
    <button class="btn btn-secondary" onclick="openEditPart(${id})">✏️ ${t('edit')}</button>
    <button class="btn btn-danger"    onclick="confirmDeletePart(${id})">🗑</button>
  `;

  showModal(esc(part.name), body, footer);
}

async function quickAdjust(id, delta) {
  const newQty = await adjustQty(id, delta);
  document.getElementById('qtyInput').value = newQty;
  const stockEl = document.querySelector('.detail-stock');
  if (stockEl) { stockEl.textContent = newQty; }
  await renderPartsList();
}

async function applyQtyInput(id) {
  const val = parseInt(document.getElementById('qtyInput')?.value) || 0;
  await setQty(id, val);
  closeModal();
  await renderPartsList();
  showToast(t('saved'), 'success');
}

async function confirmDeletePart(id) {
  const p = await getPartById(id);
  if (!p) return;
  showConfirmDialog(`${t('deleteConfirm')} "${p.name}"?`, async () => {
    await deletePart(id);
    closeModal();
    await renderPartsList();
    showToast(t('deleted'));
  }, true);
}

// ═══════════════════════════════════════════
//  ADD / EDIT PART
// ═══════════════════════════════════════════
const PART_ICONS = ['💡','🟫','🟦','🟧','🟪','🟩','🔺','🔻','🔌','🔋','⚡','🧩','🖥️','💻','📟','🎛️','📡','🌀','🧲','🛞','⚙️','🔧','🛠️','🔩','📦','🧪','🔥','❄️','⭐','🔴','🟠','🟡','🟢','🔵','🟣','⚫','⚪','🔷','🔶','⬛','⬜','◾','◽','🔘','⭕','✅','⚠️','📍','🏷️','📐','🧰','🪛','🧵','🧱','🎚️','📏','🧲','🔬','🧭','🪫'];

async function openAddPart() {
  await openPartForm(null);
}
async function openEditPart(id) {
  await openPartForm(id);
}

async function openPartForm(id) {
  const [cats, plats] = await Promise.all([
    getCategories(S.user.username),
    getPlatforms(S.user.username),
  ]);
  const part = id ? await getPartById(id) : null;

  const catOpts = cats.sort((a,b)=>a.name.localeCompare(b.name)).map(c=>
    `<option value="${esc(c.name)}" ${part?.category===c.name?'selected':''}>${esc(c.icon)} ${esc(c.name)}</option>`
  ).join('');

  const platChecks = plats.map(p =>
    `<label class="checkbox-item">
      <input type="checkbox" value="${p.id}" ${(part?.platforms||[]).includes(p.id)?'checked':''}>
      <span style="color:${p.color}">${esc(p.name)}</span>
     </label>`
  ).join('');

  const iconGrid = PART_ICONS.map(ic =>
    `<div class="icon-opt ${(part?.icon||'🔩')===ic?'selected':''}" onclick="selectIcon(this,'${ic}')" data-icon="${ic}">${ic}</div>`
  ).join('');

  const body = `
    <input type="hidden" id="pf_icon" value="${esc(part?.icon||'🔩')}">
    <div class="section-divider">${t('icon')}</div>
    <div class="icon-grid" id="iconGrid">${iconGrid}</div>

    <div class="section-divider">${t('name')} *</div>
    <input class="input" id="pf_name" placeholder="${t('name')}" value="${esc(part?.name||'')}">

    <div class="section-divider">${t('symbol')}</div>
    <input class="input" id="pf_symbol" placeholder="${t('symbol')}" value="${esc(part?.symbol||'')}">

    <div class="section-divider">${t('category')}</div>
    <select class="input" id="pf_category">
      <option value="">– brak –</option>
      ${catOpts}
    </select>

    <div class="section-divider">${t('description')}</div>
    <input class="input" id="pf_description" placeholder="${t('description')}" value="${esc(part?.description||'')}">

    <div class="section-divider">${t('quantity')} / ${t('unit')}</div>
    <div class="input-row">
      <input class="input" type="number" id="pf_quantity" placeholder="0" value="${part?.quantity||0}" min="0">
      <input class="input" id="pf_unit" placeholder="szt." value="${esc(part?.unit||'szt.')}" style="flex:0 0 80px">
    </div>

    <div class="section-divider">${t('minQty')} / ${t('maxQty')}</div>
    <div class="input-row">
      <input class="input" type="number" id="pf_minQty" placeholder="0" value="${part?.minQty||0}" min="0">
      <input class="input" type="number" id="pf_maxQty" placeholder="0" value="${part?.maxQty||0}" min="0">
    </div>

    <div class="section-divider">📍 ${t('location')}</div>
    <input class="input" id="pf_location" placeholder="np. A1-1, szuflada 3..." value="${esc(part?.location||'')}">

    <div class="section-divider">${t('price')} / waluta</div>
    <div class="input-row">
      <input class="input" type="number" id="pf_price" placeholder="0.00" value="${part?.price||''}" step="0.01" min="0">
      <input class="input" id="pf_currency" placeholder="PLN" value="${esc(part?.currency||'PLN')}" style="flex:0 0 70px">
    </div>

    <div class="section-divider">${t('compatPlatforms')}</div>
    <div class="checkbox-group">${platChecks||'<span style="color:var(--sub);font-size:13px">Brak platform — dodaj je w sidebarze.</span>'}</div>

    <div class="section-divider">${t('datasheet')}</div>
    <input class="input" id="pf_datasheet" placeholder="https://..." value="${esc(part?.datasheet||'')}">

    <div class="section-divider">${t('notes')}</div>
    <textarea class="input" id="pf_notes" placeholder="${t('notes')}">${esc(part?.notes||'')}</textarea>
  `;

  const footer = `
    <button class="btn btn-secondary" onclick="closeModal()">${t('cancel')}</button>
    <button class="btn btn-primary"   onclick="savePart(${id||'null'})">${t('save')}</button>
  `;

  showModal(part ? t('editPart') : t('addPart'), body, footer);
}

function selectIcon(el, icon) {
  document.querySelectorAll('.icon-opt').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('pf_icon').value = icon;
}

async function savePart(id) {
  const get = elId => document.getElementById(elId);
  const name = get('pf_name')?.value.trim();
  if (!name) { showToast(t('fillFields'), 'error'); return; }

  const platBoxes = document.querySelectorAll('#modalBody input[type=checkbox]');
  const selectedPlats = Array.from(platBoxes).filter(cb=>cb.checked).map(cb=>Number(cb.value));

  const data = {
    icon:        get('pf_icon')?.value || '🔩',
    name,
    symbol:      get('pf_symbol')?.value.trim()      || '',
    category:    get('pf_category')?.value            || '',
    description: get('pf_description')?.value.trim() || '',
    quantity:    parseFloat(get('pf_quantity')?.value)||0,
    unit:        get('pf_unit')?.value.trim()         || 'szt.',
    minQty:      parseFloat(get('pf_minQty')?.value)  || 0,
    maxQty:      parseFloat(get('pf_maxQty')?.value)  || 0,
    location:    get('pf_location')?.value.trim()     || '',
    price:       parseFloat(get('pf_price')?.value)   || 0,
    currency:    get('pf_currency')?.value.trim()     || 'PLN',
    platforms:   selectedPlats,
    datasheet:   get('pf_datasheet')?.value.trim()   || '',
    notes:       get('pf_notes')?.value.trim()        || '',
  };

  if (id) await updatePart(id, data);
  else     await addPart(S.user.username, data);

  closeModal();
  await renderPartsList();
  showToast(t('saved'), 'success');
}

// ═══════════════════════════════════════════
//  PART HISTORY
// ═══════════════════════════════════════════
async function openHistory(id) {
  const [part, entries] = await Promise.all([getPartById(id), getLog(S.user.username, id)]);
  const actions = { add:'✅ Dodano', edit:'✏️ Edycja', 'in':'📥 Przyjęcie', out:'📤 Wydanie', set:'🔧 Ustaw' };
  const rows = entries.map(e => {
    const d = new Date(e.at);
    const dt = `${d.toLocaleDateString()} ${d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;
    const meta = e.meta?.delta ? ` (${e.meta.delta>0?'+':''}${e.meta.delta})` : e.meta?.prev!=null ? ` ${e.meta.prev}→${e.meta.next}` : '';
    return `<div class="manager-item"><div class="manager-item-name">${actions[e.action]||e.action}${meta}</div><div style="font-size:11px;color:var(--sub)">${dt}</div></div>`;
  }).join('') || `<div style="color:var(--sub);text-align:center;padding:24px">${t('logEmpty')}</div>`;

  showModal(t('partHistory') + ': ' + esc(part?.name||''), `<div class="manager-list">${rows}</div>`, `<button class="btn btn-secondary w100" onclick="closeModal()">${t('close')}</button>`);
}

// ═══════════════════════════════════════════
//  SEARCH
// ═══════════════════════════════════════════
function renderSearch(mc) {
  mc = mc || document.getElementById('mainContent');
  mc.innerHTML = `
    <div class="page-header"><div class="page-title">🔍 ${t('search')}</div></div>
    <div class="search-bar-wrap">
      <input class="input search-input" id="searchInput" placeholder="${t('search')}..." value="${esc(S.searchQuery)}" oninput="doSearch(this.value)" autofocus>
    </div>
    <div id="searchResults"></div>
  `;
  if (S.searchQuery) doSearch(S.searchQuery);
}

async function doSearch(q) {
  S.searchQuery = q;
  const el = document.getElementById('searchResults');
  if (!el) return;
  if (!q.trim()) { el.innerHTML = `<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-sub">${t('noSearch')}</div></div>`; return; }
  const parts = await getParts(S.user.username, { q });
  if (parts.length === 0) { el.innerHTML = `<div class="empty-state"><div class="empty-sub">${t('noResults')}</div></div>`; return; }
  const cats = Object.fromEntries((await getCategories(S.user.username)).map(c=>[c.name,c]));
  const grid = makeEl('div','parts-grid');
  for (const p of parts) {
    const catIcon = cats[p.category]?.icon||'📦';
    const card = makeEl('div','part-card');
    card.innerHTML = `<div class="part-card-top"><div class="part-card-icon">${esc(p.icon||catIcon)}</div><div class="part-card-info"><div class="part-card-name">${esc(trPartName(p.name))}</div><div class="part-card-meta">${esc(p.symbol||'')} ${esc(p.category||'')} ${p.location?'📍'+esc(p.location):''}</div></div><div class="part-card-right"><div class="part-card-stock">${p.quantity}</div><div class="part-card-unit">${esc(trUnit(p.unit||'szt.'))}</div></div></div>`;
    card.onclick = () => openPartDetail(p.id);
    grid.appendChild(card);
  }
  el.innerHTML = ''; el.appendChild(grid);
}
function openSearch() { navigate('search'); }

// ═══════════════════════════════════════════
//  CATEGORY MANAGER
// ═══════════════════════════════════════════
async function openCategoryManager() {
  closeSidebar();
  const cats = await getCategories(S.user.username);
  const catIcons = ['💡','🟫','🟦','🟧','🟪','🟩','🔺','🔻','🔌','🔋','⚡','🧩','🖥️','💻','📟','🎛️','📡','🌀','🧲','🛞','⚙️','🔧','🛠️','🔩','📦','🧪','🔥','❄️','⭐','🔴','🟠','🟡','🟢','🔵','🟣','⚫','⚪','🔷','🔶','⬛','⬜','◾','◽','🔘','⭕','✅','⚠️','📍','🏷️','📐','🧰','🪛','🧵','🧱','🎚️','📏','🔬','🧭','🪫'];
  const rows = cats.sort((a,b)=>a.name.localeCompare(b.name)).map(c =>
    `<div class="manager-item">
       <div style="font-size:20px">${esc(c.icon)}</div>
       <div class="manager-item-name">${esc(c.name)}</div>
       <div class="manager-item-actions">
         <button class="btn btn-secondary btn-sm" onclick="editCategoryDlg(${c.id},'${esc(c.name)}','${esc(c.icon)}')">✏️</button>
         <button class="btn btn-danger btn-sm"    onclick="deleteCategoryConfirm(${c.id},'${esc(c.name)}')">🗑</button>
       </div>
     </div>`
  ).join('');

  const iconOpts = catIcons.map(i=>`<div class="icon-opt" onclick="selectIcon(this,'${i}')" data-icon="${i}">${i}</div>`).join('');

  const body = `
    <div class="manager-list">${rows||'<div style="color:var(--sub);text-align:center;padding:16px">Brak kategorii</div>'}</div>
    <div class="section-divider">${t('addCategory')}</div>
    <input type="hidden" id="newCatIcon" value="📦">
    <div class="icon-grid">${iconOpts}</div>
    <div class="input-row mt12">
      <input class="input" id="newCatName" placeholder="Nazwa kategorii...">
      <button class="btn btn-primary" onclick="doAddCategory()">＋</button>
    </div>
  `;
  showModal(t('catManager'), body, `<button class="btn btn-secondary w100" onclick="closeModal()">${t('close')}</button>`);
}

async function doAddCategory() {
  const name = document.getElementById('newCatName')?.value.trim();
  const icon = document.getElementById('newCatIcon')?.value || '📦';
  if (!name) { showToast(t('fillFields'),'error'); return; }
  await addCategory(S.user.username, name, icon);
  await renderSidebar();
  showToast(t('saved'),'success');
  closeModal();
  openCategoryManager();
}

async function editCategoryDlg(id, name, icon) {
  const catIcons = ['💡','🟫','🟦','🟧','🟪','🟩','🔺','🔻','🔌','🔋','⚡','🧩','🖥️','💻','📟','🎛️','📡','🌀','🧲','🛞','⚙️','🔧','🛠️','🔩','📦','🧪','🔥','❄️','⭐','🔴','🟠','🟡','🟢','🔵','🟣','⚫','⚪','🔷','🔶','⬛','⬜','◾','◽','🔘','⭕','✅','⚠️','📍','🏷️','📐','🧰','🪛','🧵','🧱','🎚️','📏','🔬','🧭','🪫'];
  const iconOpts = catIcons.map(i=>`<div class="icon-opt ${i===icon?'selected':''}" onclick="selectIcon(this,'${i}')" data-icon="${i}">${i}</div>`).join('');
  const body = `
    <input type="hidden" id="editCatIcon" value="${esc(icon)}">
    <div class="icon-grid">${iconOpts}</div>
    <div class="form-group mt12">
      <label class="form-label">${t('name')}</label>
      <input class="input" id="editCatName" value="${esc(name)}">
    </div>
  `;
  showModal(t('editCategory'), body, `
    <button class="btn btn-secondary" onclick="openCategoryManager()">${t('cancel')}</button>
    <button class="btn btn-primary"   onclick="doEditCategory(${id})">💾 ${t('save')}</button>
  `);
}

async function doEditCategory(id) {
  const name = document.getElementById('editCatName')?.value.trim();
  const icon = document.getElementById('editCatIcon')?.value || '📦';
  if (!name) return;
  await updateCategory(id, name, icon);
  await renderSidebar();
  showToast(t('saved'),'success');
  closeModal();
}

async function deleteCategoryConfirm(id, name) {
  showConfirmDialog(`${t('deleteConfirm')} "${name}"?`, async () => {
    await deleteCategory(id);
    await renderSidebar();
    showToast(t('deleted'));
    closeModal();
    openCategoryManager();
  }, true);
}

// ═══════════════════════════════════════════
//  PLATFORM MANAGER
// ═══════════════════════════════════════════
async function openPlatformManager() {
  closeSidebar();
  const plats = await getPlatforms(S.user.username);
  const rows = plats.sort((a,b)=>a.name.localeCompare(b.name)).map(p =>
    `<div class="manager-item">
       <div style="width:14px;height:14px;border-radius:50%;background:${p.color};flex-shrink:0"></div>
       <div class="manager-item-name">${esc(p.name)}</div>
       <div class="manager-item-actions">
         <button class="btn btn-secondary btn-sm" onclick="editPlatformDlg(${p.id},'${esc(p.name)}','${esc(p.color)}')">✏️</button>
         <button class="btn btn-danger btn-sm"    onclick="deletePlatformConfirm(${p.id},'${esc(p.name)}')">🗑</button>
       </div>
     </div>`
  ).join('');
  const body = `
    <div class="manager-list">${rows||'<div style="color:var(--sub);text-align:center;padding:16px">Brak platform</div>'}</div>
    <div class="section-divider">${t('addPlatform')}</div>
    <div class="input-row mt8">
      <input class="input" id="newPlatName" placeholder="np. Arduino, ESP32...">
      <input type="color" id="newPlatColor" value="#ff0000" style="width:44px;height:44px;border:none;background:none;cursor:pointer">
      <button class="btn btn-primary" onclick="doAddPlatform()">＋</button>
    </div>
  `;
  showModal(t('platManager'), body, `<button class="btn btn-secondary w100" onclick="closeModal()">${t('close')}</button>`);
}

async function doAddPlatform() {
  const name  = document.getElementById('newPlatName')?.value.trim();
  const color = document.getElementById('newPlatColor')?.value || '#ff0000';
  if (!name) { showToast(t('fillFields'),'error'); return; }
  await addPlatform(S.user.username, name, color);
  await renderSidebar();
  showToast(t('saved'),'success');
  closeModal();
  openPlatformManager();
}

async function editPlatformDlg(id, name, color) {
  const body = `
    <div class="form-group"><label class="form-label">${t('name')}</label><input class="input" id="editPlatName" value="${esc(name)}"></div>
    <div class="form-group"><label class="form-label">${t('color')}</label><input type="color" id="editPlatColor" value="${esc(color)}" style="width:60px;height:44px;border:none;background:none;cursor:pointer"></div>
  `;
  showModal(t('editPlatform'), body, `
    <button class="btn btn-secondary" onclick="openPlatformManager()">${t('cancel')}</button>
    <button class="btn btn-primary"   onclick="doEditPlatform(${id})">💾 ${t('save')}</button>
  `);
}
async function doEditPlatform(id) {
  const name  = document.getElementById('editPlatName')?.value.trim();
  const color = document.getElementById('editPlatColor')?.value || '#388BFD';
  if (!name) return;
  await updatePlatform(id, name, color);
  await renderSidebar(); showToast(t('saved'),'success'); closeModal();
}
async function deletePlatformConfirm(id, name) {
  showConfirmDialog(`${t('deleteConfirm')} "${name}"?`, async () => {
    await deletePlatform(id); await renderSidebar(); showToast(t('deleted'));
    closeModal(); openPlatformManager();
  }, true);
}

// ═══════════════════════════════════════════
//  SETTINGS
// ═══════════════════════════════════════════
function renderSettings(mc) {
  mc = mc || document.getElementById('mainContent');
  const langOpts = [
    {code:'pl',label:'🇵🇱 Polski'},
    {code:'en',label:'🇬🇧 English'},
    {code:'es',label:'🇪🇸 Español'},
  ];

  mc.innerHTML = `
    <div class="page-header"><div class="page-title">⚙️ ${t('settings')}</div></div>

    <div class="settings-section">
      <div class="settings-section-title">${t('userSettings')}</div>
      <div class="settings-row">
        <div><div class="settings-row-label">👤 ${t('username')}</div><div class="settings-row-sub">${esc(S.user.username)}</div></div>
      </div>
      <div class="settings-row">
        <div class="settings-row-label">🎨 ${t('themeLabel')}</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sm ${S.theme==='dark'?'btn-primary':'btn-secondary'}" onclick="setTheme('dark')">${t('dark')}</button>
          <button class="btn btn-sm ${S.theme==='light'?'btn-primary':'btn-secondary'}" onclick="setTheme('light')">${t('light')}</button>
        </div>
      </div>
      <div class="settings-row">
        <div class="settings-row-label">🌐 ${t('language')}</div>
        <select class="input" style="max-width:180px" onchange="setLang(this.value)">
          ${langOpts.map(l=>`<option value="${l.code}" ${S.lang===l.code?'selected':''}>${l.label}</option>`).join('')}
        </select>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">${t('backup')}</div>
      <div class="settings-row">
        <div class="settings-row-label">📤 ${t('exportJson')}</div>
        <button class="btn btn-secondary btn-sm" onclick="exportData()">${t('export')}</button>
      </div>
      <div class="settings-row">
        <div class="settings-row-label">📥 ${t('importJson')}</div>
        <button class="btn btn-secondary btn-sm" onclick="startImport()">${t('import')}</button>
      </div>
    </div>

    <div class="settings-section danger-settings">
      <div class="settings-section-title">${t('dangerZone')}</div>
      <div class="settings-row">
        <div><div class="settings-row-label" style="color:var(--danger)">🧹 ${t('deleteStock')}</div><div class="settings-row-sub">${t('deleteStockSub')}</div></div>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteStockOnly()">${t('delete')}</button>
      </div>
      <div class="settings-row">
        <div><div class="settings-row-label" style="color:var(--danger)">🗑 ${t('deleteAllData')}</div><div class="settings-row-sub">${t('deleteAllSub')}</div></div>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteAll()">${t('delete')}</button>
      </div>
    </div>

    <div class="settings-section">
      <div class="settings-section-title">${t('accountAbout')}</div>
      <div class="settings-row"><div><div class="settings-row-label">ElectroStock</div><div class="settings-row-sub">${t('version')} 1.0</div></div></div>
      <div class="settings-row"><div><div class="settings-row-label">${t('storage')}</div><div class="settings-row-sub">${t('localData')}</div></div></div>
    </div>
  `;
}

async function setTheme(theme) {
  S.theme = theme; applyTheme();
  await updateUserSettings(S.user.username, { theme });
  renderSettings();
}

async function setLang(lang) {
  S.lang = ['pl','en','es'].includes(lang) ? lang : 'pl';
  localStorage.setItem('es_lang', S.lang);
  const authLang = document.getElementById('authLang');
  if (authLang) authLang.value = S.lang;
  if (S.user?.username) {
    await updateUserSettings(S.user.username, { lang: S.lang });
    S.user = await getUser(S.user.username);
    await renderSidebar();
  }
  navigate(S.view);
}


async function confirmDeleteStockOnly() {
  showConfirmDialog(`${t('deleteStock')}?`, async () => {
    const parts = await getParts(S.user.username);
    for (const p of parts) await deletePart(p.id);
    if (typeof deleteLogForUser === 'function') await deleteLogForUser(S.user.username);
    S.filterCat = null;
    S.filterPlat = null;
    S.view = 'all';
    await renderSidebar();
    showToast(t('deleted'));
    navigate('all');
  }, true);
}

async function confirmDeleteAll() {
  showConfirmDialog(`${t('deleteAllData')}?`, async () => {
    const [parts, cats, plats] = await Promise.all([
      getParts(S.user.username),
      getCategories(S.user.username),
      getPlatforms(S.user.username),
    ]);
    for (const p of parts)  await deletePart(p.id);
    for (const c of cats)   await deleteCategory(c.id);
    for (const p of plats)  await deletePlatform(p.id);
    showToast(t('deleted'));
    navigate('all');
  }, true);
}

// ═══════════════════════════════════════════
//  EXPORT / IMPORT
// ═══════════════════════════════════════════
async function exportData() {
  const data = await exportUserData(S.user.username);
  const json = JSON.stringify(data, null, 2);
  const filename = `electrostock_${S.user.username}_${new Date().toISOString().slice(0,10)}.json`;
  if (window.AndroidBridge) {
    try {
      window.AndroidBridge.exportJson(filename, json);
      return;
    } catch (e) {
      console.warn('Native export failed, using browser fallback', e);
    }
  }
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast(t('exportOk'), 'success');
}

function startImport() {
  if (window.AndroidBridge) {
    try {
      window.AndroidBridge.importJson();
      return;
    } catch (e) {
      console.warn('Native import failed, using browser fallback', e);
    }
  }
  document.getElementById('importFile').click();
}

async function handleImportedJson(text) {
  try {
    const data = JSON.parse(text);
    await importUserData(S.user.username, data);
    await renderSidebar();
    await renderPartsList();
    showToast(t('importOk'), 'success');
  } catch (e) {
    console.error(e);
    showToast(t('importErr'), 'error');
  }
}

async function importData(event) {
  const file = event.target.files[0]; if (!file) return;
  await handleImportedJson(await file.text());
  event.target.value = '';
}

window.receiveImportedJson = function(text) { handleImportedJson(text); };
window.nativeExportDone = function(ok) { showToast(ok ? t('exportOk') : t('error'), ok ? 'success' : 'error'); };
window.nativeImportError = function() { showToast(t('importErr'), 'error'); };


// ═══════════════════════════════════════════
//  CUSTOM CONFIRM DIALOG
// ═══════════════════════════════════════════
function showConfirmDialog(message, onConfirm, danger=false) {
  const footer = `
    <button class="btn" onclick="closeModal()">${t('cancel')}</button>
    <button class="btn ${danger ? 'danger' : 'primary'}" id="confirmDialogOk">${t('confirm')}</button>
  `;
  showModal(t('confirm'), `<p class="confirm-message">${message}</p>`, footer);
  const okBtn = document.getElementById('confirmDialogOk');
  if (okBtn) {
    okBtn.onclick = async () => {
      await onConfirm();
    };
  }
}

// ═══════════════════════════════════════════
//  MODAL
// ═══════════════════════════════════════════
function showModal(title, body, footer='') {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML   = body;
  document.getElementById('modalFooter').innerHTML = footer;
  document.getElementById('modalOverlay').classList.remove('hidden');
}
function closeModal() {
  document.getElementById('modalOverlay').classList.add('hidden');
}
function closeModalOuter(e) {
  if (e.target === document.getElementById('modalOverlay')) closeModal();
}

// ═══════════════════════════════════════════
//  TOAST
// ═══════════════════════════════════════════
let toastTimer = null;
function showToast(msg, type='') {
  const el = document.getElementById('toast');
  el.textContent = msg; el.className = `toast ${type}`;
  el.classList.remove('hidden');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2400);
}

// ═══════════════════════════════════════════
//  UTILS
// ═══════════════════════════════════════════
function makeEl(tag, className='', text='') {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text) el.textContent = text;
  return el;
}
function esc(str) {
  if (str == null) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

// Enter key in login form
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    if (!document.getElementById('loginView').classList.contains('hidden')) doAuth();
  }
});
